package com.goggxi.yt_flutter_movie_db

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
