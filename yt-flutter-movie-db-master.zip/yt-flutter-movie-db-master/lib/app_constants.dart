class AppConstants {
  static const String baseUrl = 'https://api.themoviedb.org/3';
  static const String imageUrlW500 = 'https://image.tmdb.org/t/p/w500';
  static const String imageUrlOriginal = 'https://image.tmdb.org/t/p/original';
  // static const String apiKey = 'd8e957a69af1be921c9c4466f5661e87';
  static const String apiKey = '70b45c38319e916c73f939b303da9804';


}
