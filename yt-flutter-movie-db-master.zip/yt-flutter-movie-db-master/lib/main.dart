import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'package:provider/provider.dart';
import 'package:yt_flutter_movie_db/injector.dart';
import 'package:yt_flutter_movie_db/movie/pages/movie_page.dart';
import 'package:yt_flutter_movie_db/movie/providers/movie_get_discover_provider.dart';
import 'package:yt_flutter_movie_db/movie/providers/movie_get_now_playing_provider.dart';
import 'package:yt_flutter_movie_db/movie/providers/movie_get_top_rated_provider.dart';

import 'movie/providers/movie_serach_provider.dart';

import 'package:yt_flutter_movie_db/movie/pages/login.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';

// import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
// import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart'; // Import Firebase Auth
import 'package:yt_flutter_movie_db/features/app/splash_screen/splash_screen.dart';
import 'package:yt_flutter_movie_db/features/user_auth/presentation/pages/home_page.dart';
import 'package:yt_flutter_movie_db/features/user_auth/presentation/pages/login_page.dart';
import 'package:yt_flutter_movie_db/features/user_auth/presentation/pages/sign_up_page.dart';


// Future main() async{
//   WidgetsFlutterBinding.ensureInitialized();
//   await Firebase.initializeApp();

//   void main() {
//
//   WidgetsBinding widgetsBinding = WidgetsFlutterBinding.ensureInitialized();
//   FlutterNativeSplash.preserve(widgetsBinding: widgetsBinding);
//   setup();
//   runApp(const App());
//   FlutterNativeSplash.remove();
// }

Future main() async {
  WidgetsFlutterBinding.ensureInitialized();

  setup();
  FlutterNativeSplash.remove();

  if (kIsWeb) {
    await Firebase.initializeApp(
      options: FirebaseOptions(
        apiKey: "AIzaSyCsHDQtI9DItQgSqwy45_y2xG9tDGxuER8",
        appId: "1:540215271818:web:8b22d4aee01acdce862873",
        messagingSenderId: "540215271818",
        projectId: "flutter-firebase-9c136",
        // Your web Firebase config options
      ),
    );
  } else {
    await Firebase.initializeApp();
  }
  runApp(App());
}

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) {



    // MultiProvider
    return MultiProvider(

      providers: [
        ChangeNotifierProvider(
          create: (_) => sl<MovieGetDiscoverProvider>(),
        ),
        ChangeNotifierProvider(
          create: (_) => sl<MovieGetTopRatedProvider>(),
        ),
        ChangeNotifierProvider(
          create: (_) => sl<MovieGetNowPlayingProvider>(),
        ),
        ChangeNotifierProvider(
          create: (_) => sl<MovieSearchProvider>(),
        ),
      ],

      child: MaterialApp(

        routes: {
          // '/': (context) => SplashScreen(
          //   // Here, you can decide whether to show the LoginPage or HomePage based on user authentication
          //   child: LoginPage(),
          // ),
          '/login': (context) => LoginPage(),
          '/signUp': (context) => SignUpPage(),
          '/home': (context) => HomePage(),
          '/movie': (context) => MoviePage(),
        },

        title: 'Movie DB',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        home:  LoginPage(),
        // MoviePage
        debugShowCheckedModeBanner: false,

      ),



    );
  }
}

// class Mainpage extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) => Scaffold(
//     body: StreamBuilder<User?>(
//       stream: FirebaseAuth.instance.authStateChanges(),
//       builder: (context, snapshot){
//         if (snapshot.hasData) {
//           return MoviePage();
//         } else {
//           return MyApp();
//         }
//       },
//     ),
//   );
// }
// Future main() async{
//   WidgetsFlutterBinding.ensureInitialized();
//   await Firebase.initializeApp();
// }

// void main() {
